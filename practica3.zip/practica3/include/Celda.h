#ifndef Celda_h
#define Celda_h

struct Celda{
    int dato;
    int max;
};

#endif // Celda_h